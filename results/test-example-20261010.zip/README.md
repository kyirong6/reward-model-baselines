# Music reward-model example evaluation — 2026-10-10

Four models evaluated the same ten audio pairs: five vocal and five instrumental.
All four Slurm jobs completed successfully with exit code 0:0 on NVIDIA L40S GPUs.
This is a small pilot to demonstrate inference outputs, not a reliable model ranking.

## Results

| Model | Overall accuracy | Vocal | Instrumental | Loading | Total runner time | Peak GPU memory |
|---|---:|---:|---:|---:|---:|---:|
| SongEval | 40% | 20% | 60% | 7.62 s | 15.94 s | 9.44 GiB |
| TuneJury | 50% | 20% | 80% | 12.02 s | 23.86 s | 6.75 GiB |
| CMI | 70% | 80% | 60% | 9.68 s | 17.00 s | 3.02 GiB |
| MuseCritic | 40% | 40% | 40% | 144.67 s | 481.93 s | 20.13 GiB |

Total runner time includes loading and evaluation, but excludes scheduler overhead.
There were no exact ties. CMI alignment-only accuracy was also 70%.

## Preference rule and dimensions

Each model scores audio A and B independently. The higher unweighted mean of its
returned scores determines the preference. Scores are not normalized or weighted.
Exact ties count as incorrect. Raw scales should not be compared across models.

- SongEval: Coherence, Musicality, Memorability, Clarity, Naturalness.
- TuneJury: one reward score (its mean is the reward itself).
- CMI: alignment and quality; alignment-only decisions are retained separately.
- MuseCritic: the same five dimension names as SongEval, plus a generated critique
  for each audio. Its inference generates a critique and then computes scores
  conditioned on the generated sequence; this takes longer than direct scoring.

## Files

- summary.csv: spreadsheet-friendly accuracy, runtime, and memory overview.
- dimension_scores.csv: spreadsheet-friendly individual dimension scores for both
  audios, with model/run/pair identifiers, predictions, and means.
- combined_predictions.jsonl: 40 records (four models x ten pairs), preserving
  individual scores, means, predictions, correctness, pair inputs, and critiques.
- combined_summary.json: metadata and summaries grouped by model and run ID.
- results/MODEL-TIMESTAMP/: original pairs.jsonl, predictions.jsonl, run.json,
  and summary.json for each of the four selected runs.
- logs/: original stdout/stderr logs for each selected job.

Only these four ten-pair runs are included; historical smoke tests are excluded.
JSONL has one JSON object per line. CSV files are UTF-8; some critiques are Chinese.
The per-audio critiques remain in JSONL rather than the dimension-score CSV.
Original cluster paths are retained for provenance. Audio files and model weights
are not included in this results archive, so those paths do not resolve elsewhere.
Run metadata includes PyTorch/GPU/seed/settings, but not checkpoint hashes or code
commit IDs. CMI uses the compatible CPU TorchCodec decoder while inference uses GPU.
